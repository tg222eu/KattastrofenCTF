En statstjänsteman på en skyddsvärd myndighet är svag för bilder på kattungar.
I sin iver att ta del av fler sådana bilder, har hen råkat ladda ned något som
inte var bra. Inte alls bra. Vi misstänker att skadlig kod har använts för att
exfiltrera topphemlig data från myndigheten. Analysera nätverkstrafiken för att
ta reda på vad som har hänt.

Utmaningen innehåller tre flaggor på formen /flagga[1-3]{[a-zå-ö_!]+}/ - kan du
hitta dem?

Skicka in din lösning till rekrytering@fra.se, även om du inte lyckas hitta
samtliga flaggor!

